require 'mkmf'
create_makefile('stfl')
